enum {
  !COM = 0,
  !LPT = 1
};
