enum {
  !NULL = 0,
  !EOF = -1,
  !MAX_PATH = 260
};
