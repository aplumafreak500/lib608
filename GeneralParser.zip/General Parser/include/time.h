enum {
  !CLOCKS_PER_SEC = 1000
};
